const textEl = document.querySelector('#text');

async function handleClipboardWrite(data) {
  try {
    if (typeof data !== 'string') {
      throw new TypeError(`Value provided must be a 'string', got '${typeof data}'.`);
    }
    textEl.value = data;
    textEl.select();
    document.execCommand('copy');
  } finally {
    window.close();
  }
}

chrome.runtime.onMessage.addListener(async (message) => {
  if (message.target === 'offscreen-doc' && message.type === 'copy-data-to-clipboard') {
    await handleClipboardWrite(message.data);
  }
});
